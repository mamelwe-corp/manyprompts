export default function Guest({ children }) {
    return <div className="h-full">{children}</div>;
}
