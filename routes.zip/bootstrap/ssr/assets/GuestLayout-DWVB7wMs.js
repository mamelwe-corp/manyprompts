import { jsx } from "react/jsx-runtime";
function Guest({ children }) {
  return /* @__PURE__ */ jsx("div", { className: "h-full", children });
}
export {
  Guest as G
};
