export default function ApplicationLogo(props) {
    return <h1 className="text-xl font-bold italic">@MANYPROMPTS</h1>;
}
